
library(mvtnorm)
library(glmnet)
library(survival)
source("coxph_as.R")
library(emulator)
library(MASS)
library(parallel)
numCores=detectCores()
generate_synthetic_X <- function(X_obs, M) {
  apply(X_obs, 2, function(v) {
    u <- sample(v, size = M, replace = TRUE)
    if (length(unique(v)) <= 2) {
      ind <- sample(c(TRUE, FALSE), M, replace = TRUE)
      u[ind] <- rbinom(sum(ind), 1, 0.5)
    }
    u
  })
}

N_rep=100
M=1000
n=100

NUM_TUNING=100

h0_indication="const"
rho=0.5
censor_rate=0.2
p=40


source("Bayesian_cox_cat_prior_tau.R")

FILENAME=paste0("p",p,"censor",censor_rate*10,"n",n)
load(paste0(FILENAME,"bayefitcoverage_tauprior"))
load(paste0(FILENAME,"bayefitmean_tauprior"))
load(paste0(FILENAME,"square_loss"))

need_resample_index=which(beta_coverage_tauprior_store<0.1)
need_resample_index
for(rep_index in need_resample_index){
  set.seed(50+rep_index)
  print(paste0(n,"rep:",rep_index))
  X_obs <- matrix(rnorm(n * p), n, p)
  #X_obs<-scale(X_obs)
  X_obs[, 1] <- rbinom(n, 1, 0.9)
  
  X_obs[, 3] <- rchisq(n,1)
  X_obs[, 2] <- rchisq(n,4)
  
  X=X_obs
  beta= c(4, -4, 3, -3, 1,-1,1,-1 ,rep(1, p-8))/sqrt(p)
  
  Xbeta=as.numeric(X%*%beta)
  TT <-sapply(1:n,function(i){rexp(1,0.5*exp(Xbeta[i]))})
  if(censor_rate==0){
    C=rep(4000000,n)
  }
  if(censor_rate==0.2){
    pre_value=quantile(TT,0.90)
    
    C=runif(n,0,pre_value)
    censor_rates=sum(C<TT)/n
    target_censor_rate=censor_rate
    while(abs(target_censor_rate-censor_rates)>0.02){
      C=runif(n,0,pre_value)
      censor_rates=sum(C<TT)/n
      #print(censor_rates)
    }
  }
  Y_status=t(sapply(1:n,function(aa){
    c(min(C[aa],TT[aa]),(C[aa]>TT[aa]))
  }))
  Y=Y_status[,1]
  status=Y_status[,2]
  
  
  
  X.syn=X.syn=generate_synthetic_X(X, M)
  rate_exp=sum(status)/mean(Y)/n
  T.syn=rexp(M,rate=rate_exp)
  increase_order=order(T.syn)
  X.syn=X.syn[increase_order,]
  T.syn=T.syn[increase_order]
  status.syn=rep(1,M)
  syntheticObj	<- list()
  syntheticObj$M=M
  syntheticObj$xstar=X.syn
  syntheticObj$ystar=T.syn
  syntheticObj$h_star=rate_exp
  my_syndata<-list(T.syn=syntheticObj$ystar,X.syn=syntheticObj$xstar,status.syn=rep(1,M),h_star=rate_exp)
  
  if(all_result_squareloss_matrix[rep_index,7]==1){
    beta_coverage_tauprior_store[rep_index]=1000
    betahat_baye_tauprior_store[rep_index,]=rep(2000,p)
    
  }else{
    set.seed(66)
    fit_prior_tau=Bayesian_cox_cat_stan(X, Y, status, X.syn, T.syn, status.syn)
    LOWER95=summary(fit_prior_tau)$summary[1:p,"2.5%"]
    UPPER95=summary(fit_prior_tau)$summary[1:p,"97.5%"]
    
    beta_coverage_tauprior_store[rep_index]=mean(beta<UPPER95 & beta>LOWER95)
    betahat_baye_tauprior_store[rep_index,]=summary(fit_prior_tau)$summary[1:p,1]
    
  }
}

save(betahat_baye_tauprior_store,file = paste0(FILENAME,"bayefitmean_tauprior"))
save(beta_coverage_tauprior_store,file = paste0(FILENAME,"bayefitcoverage_tauprior"))


