# summary of result
library(ggplot2)
p=20
N_rep=100
censor_rate=0.2
beta= c(4, -4, 3, -3, 1,-1,1,-1 ,rep(1, p-8))/sqrt(p)
n_seq=c(100,150,200)


method_square_loss=c("MPLE","Ridge","Lasso","RE_cv","RE_p","Mix","Post_mean_cv","Post_mean_p")

for_plot_data_square_loss=data.frame()

for(n in c(100,150,200)){
  FILENAME_squareloss=paste0( "p",p,"censor",censor_rate*10,"n",n,"square_loss")
  FILENAME_BAYECV_squareloss=paste0("p",p,"censor",censor_rate*10,"n",n,"bayefitmean_cv")
  FILENAME_BAYEP_squareloss=paste0("p",p,"censor",censor_rate*10,"n",n,"bayefitmean_p")
  load(FILENAME_squareloss);load(FILENAME_BAYECV_squareloss);load(FILENAME_BAYEP_squareloss)
  
  all_squareloss_matrix=matrix(0,nc=8,nr=N_rep)
  for (ii in 1:N_rep) {
    post_meancv=betahat_baye_cv_store[ii,]
    post_meanp=betahat_baye_taup_store[ii,]
    all_squareloss_matrix[ii,]=c(all_result_squareloss_matrix[ii,1:6],
                                 norm(beta-post_meancv,"2")^2,
                                 norm(beta-post_meanp,"2")^2)
  }
  
  
  
  if(sum(all_result_squareloss_matrix[,7])>0){
    breakup_indicator=which(all_result_squareloss_matrix[,7]==1)
    this_n_infor_squareloss=data.frame(n=rep(n,8),method=method_square_loss,
                                       avg=apply(all_squareloss_matrix[-breakup_indicator,],2,mean)[1:8],
                                       err=apply(all_squareloss_matrix[-breakup_indicator,],2,sd)[1:8]/sqrt(100))
    
  }else{
    this_n_infor_squareloss=data.frame(n=rep(n,8),method=method_square_loss,avg=apply(all_squareloss_matrix,2,mean)[1:8],
                                       err=apply(all_squareloss_matrix,2,sd)[1:8]/sqrt(100))
    
  }
  for_plot_data_square_loss=rbind(for_plot_data_square_loss,this_n_infor_squareloss)
  
}

for_plot_data_square_loss

ggplot(for_plot_data_square_loss, aes(x=n, y=avg, group=method, color=method)) + 
  geom_line() +
  geom_point()+#ylim(0, 2)+
  geom_errorbar(aes(ymin=avg-err, ymax=avg+err), width=.2,
                position=position_dodge(0.05))+ylab("MSE")




# prediction result -------------------------------------------------------
library(mvtnorm)
library(glmnet)
library(survival)
source("coxph_as.R")
library(emulator)
library(MASS)
predict_goodness_compute<-function(betahat,X_test,Y_test,status_test){
  p=ncol(X_test)
  term1=CoxPL(betahat,X_test,rep(0,length(Y_test)),Y_test,status_test)
  term2=CoxPL(rep(0,p),X_test,rep(0,length(Y_test)),Y_test,status_test)
  return(term1-term2)
}

pred_goodness_each_setting<-function(N_rep=100,n,censor_rate,p,N_testing_point=100){
  
  load(paste0( "p",p,"censor",censor_rate*10,"n",n,"square_loss"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"betahat_MPLE"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"betahat_taucv"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"betahat_taup"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"betahat_lassocv"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"betahat_ridgecv"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"betahat_taumixcv"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"bayefitmean_cv"))
  load(paste0("p",p,"censor",censor_rate*10,"n",n,"bayefitmean_p"))
  
  
  pred_goodness_truth_vector=rep(0,N_rep)
  pred_goodness_MPLE_vector=rep(0,N_rep)
  pred_goodness_ridgecv_vector=rep(0,N_rep)
  pred_goodness_lassocv_vector=rep(0,N_rep)
  pred_goodness_taumixcv_vector=rep(0,N_rep)
  pred_goodness_taucv_vector=rep(0,N_rep)
  pred_goodness_taup_vector=rep(0,N_rep)
  pred_goodness_postmeantaucv_vector=rep(0,N_rep)
  pred_goodness_postmeantaup_vector=rep(0,N_rep)
  
  
  for(rep_index in 1:N_rep){
    
    set.seed(10000+rep_index)
    X_obs <- matrix(rnorm(n * p), n, p)
    #X_obs<-scale(X_obs)
    X_obs[, 1] <- rbinom(n, 1, 0.9)
    
    X_obs[, 3] <- rchisq(n,1)
    X_obs[, 2] <- rchisq(n,4)
    
    X=X_obs
    beta= c(4, -4, 3, -3, 1,-1,1,-1 ,rep(1, p-8))/sqrt(p)
    
    Xbeta=as.numeric(X%*%beta)
    TT <-sapply(1:n,function(i){rexp(1,0.5*exp(Xbeta[i]))})
    if(censor_rate==0){
      C=rep(4000000,n)
    }
    if(censor_rate==0.2){
      pre_value=quantile(TT,0.90)
      
      C=runif(n,0,pre_value)
      censor_rates=sum(C<TT)/n
      target_censor_rate=censor_rate
      while(abs(target_censor_rate-censor_rates)>0.02){
        C=runif(n,0,pre_value)
        censor_rates=sum(C<TT)/n
        #print(censor_rates)
      }
    }
    Y_status=t(sapply(1:n,function(aa){
      c(min(C[aa],TT[aa]),(C[aa]>TT[aa]))
    }))
    Y=Y_status[,1]
    status=Y_status[,2]
    
    pred_goodness_truth_vector[rep_index ] = predict_goodness_compute(beta, X, Y, status)
    pred_goodness_MPLE_vector[rep_index ] = pred_goodness_truth_vector[rep_index ]-predict_goodness_compute(betahat_MPLE_store[rep_index, ], X, Y, status)
    pred_goodness_ridgecv_vector[rep_index ] = pred_goodness_truth_vector[rep_index ]- predict_goodness_compute(betahat_ridge_cv_store[rep_index, ], X, Y, status)
    pred_goodness_lassocv_vector[rep_index]= pred_goodness_truth_vector[rep_index ]-predict_goodness_compute(betahat_lasso_cv_store[rep_index, ], X, Y, status)
    pred_goodness_taumixcv_vector[rep_index]= pred_goodness_truth_vector[rep_index ]-predict_goodness_compute(betahat_mixcat_cv_store[rep_index,],X, Y, status)
    pred_goodness_taucv_vector[rep_index ] =  pred_goodness_truth_vector[rep_index ]-predict_goodness_compute(betahat_pencat_cv_store[rep_index, ], X, Y, status)
    pred_goodness_taup_vector[rep_index ] =  pred_goodness_truth_vector[rep_index ]-predict_goodness_compute(betahat_pencat_taup_store[rep_index, ], X, Y, status)
    pred_goodness_postmeantaucv_vector[rep_index ] =  pred_goodness_truth_vector[rep_index ]-predict_goodness_compute(betahat_baye_cv_store[rep_index,], X, Y, status)
    pred_goodness_postmeantaup_vector[rep_index ] = pred_goodness_truth_vector[rep_index ]- predict_goodness_compute(betahat_baye_taup_store[rep_index,], X, Y, status)
    
  }
  
  final_matrix=matrix(0,nr=2,nc=8)
  
  breakup_indicator=NULL
  if(sum(all_result_squareloss_matrix[,7])>0){
    breakup_indicator=which(all_result_squareloss_matrix[,7]==1)
  }
  if(is.null(breakup_indicator)){
    
    final_matrix[,2-1]=c(mean(pred_goodness_MPLE_vector) ,sd(pred_goodness_MPLE_vector)/sqrt(N_rep))
    final_matrix[,3-1]=c(mean( pred_goodness_ridgecv_vector) ,sd(pred_goodness_ridgecv_vector)/sqrt(N_rep))
    final_matrix[,4-1]=c(mean( pred_goodness_lassocv_vector) ,sd(pred_goodness_lassocv_vector)/sqrt(N_rep))
    final_matrix[,5-1]=c(mean( pred_goodness_taucv_vector ),sd(pred_goodness_taucv_vector)/sqrt(N_rep))
    final_matrix[,6-1]=c(mean( pred_goodness_taup_vector ),sd(pred_goodness_taup_vector)/sqrt(N_rep))
    final_matrix[,7-1]=c(mean( pred_goodness_taumixcv_vector ),sd(pred_goodness_taumixcv_vector)/sqrt(N_rep))
    final_matrix[,8-1]=c(mean( pred_goodness_postmeantaucv_vector ),sd(pred_goodness_postmeantaucv_vector)/sqrt(N_rep))
    final_matrix[,9-1]=c(mean( pred_goodness_postmeantaup_vector ),sd(pred_goodness_postmeantaup_vector)/sqrt(N_rep))
  }
  if(!is.null(breakup_indicator)){
    
    final_matrix[,2-1]=c(mean(pred_goodness_MPLE_vector[-breakup_indicator]) ,sd(pred_goodness_MPLE_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,3-1]=c(mean( pred_goodness_ridgecv_vector[-breakup_indicator]) ,sd(pred_goodness_ridgecv_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,4-1]=c(mean( pred_goodness_lassocv_vector[-breakup_indicator]) ,sd(pred_goodness_lassocv_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,5-1]=c(mean( pred_goodness_taucv_vector[-breakup_indicator] ),sd(pred_goodness_taucv_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,6-1]=c(mean( pred_goodness_taup_vector[-breakup_indicator] ),sd(pred_goodness_taup_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,7-1]=c(mean( pred_goodness_taumixcv_vector[-breakup_indicator] ),sd(pred_goodness_taumixcv_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,8-1]=c(mean( pred_goodness_postmeantaucv_vector[-breakup_indicator] ),sd(pred_goodness_postmeantaucv_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
    final_matrix[,9-1]=c(mean( pred_goodness_postmeantaup_vector[-breakup_indicator] ),sd(pred_goodness_postmeantaup_vector[-breakup_indicator])/sqrt(N_rep-length(breakup_indicator)))
  }
  
  
  colnames(final_matrix)=c("MPLE","Ridge","Lasso","RE_cv","RE_p","Mix","Post_mean_cv","Post_mean_p")
  rownames(final_matrix)=c("average_preddeviance","stderr_preddeviance")
  #write.csv(final_matrix,file = paste0(FILENAME,".csv"))
  return(final_matrix)
  
  
}

gd_result=t(pred_goodness_each_setting(n=100,censor_rate = censor_rate,p=p))
gd_result=as.data.frame(gd_result)
gd_result$average_mse=as.numeric(for_plot_data_square_loss[1:8,3])
gd_result$stderr_mse=as.numeric(for_plot_data_square_loss[1:8,4])
all_result=round(gd_result,2)
write.csv(all_result,file =paste0( "All_result_p",p,"censor",censor_rate*10,"n",n,".csv"))





